﻿using ForumApp.Data.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForumApp.Data.Services
{
    public class PostService
    {
        private readonly ForumDbContext _context;

        public PostService(ForumDbContext context)
        {
            _context = context;
        }

        public List<PostViewDTO> GetAllPosts()
        {
            return _context.Posts
                .Select(p => new PostViewDTO
                {
                    Id = p.Id,
                    Title = p.Title,
                    Content = p.Content,
                    AuthorName = p.Author.Username,
                    CategoryName = p.Category.Name,
                    CreatedOn = p.CreatedOn
                })
                .OrderByDescending(p => p.CreatedOn)
                .ToList();
        }

        public void CreatePost(PostCreateDTO dto)
        {
            var post = new Post
            {
                Title = dto.Title,
                Content = dto.Content,
                AuthorId = dto.AuthorId,
                CategoryId = dto.CategoryId,
                CreatedOn = DateTime.Now
            };

            _context.Posts.Add(post);
            _context.SaveChanges();
        }

        public Dictionary<int, string> GetCategories()
        {
            return _context.Categories.ToDictionary(c => c.Id, c => c.Name);
        }
    }
}
